
import java.util.Date;

public class Cita
{
    private Date fecha;
    private Persona contacto;
    private Lugar unLugar;
    private int importancia;
    
    public void setFecha(Date fecha){
        this.fecha=fecha;
    }
    public Date getFecha(){
        System.out.println("La fecha es: "+fecha);
        return fecha;
    }
    
    public void setImportancia(int importancia){
        this.importancia=importancia;
    }
    public int getImportancia(){
        return importancia;
    }
    
    public void setContacto(Persona contacto){
        this.contacto=contacto;
    }
    public Persona getContacto(){
        return contacto;
    }
    
    public void setLugar(Lugar unLugar){
        this.unLugar=unLugar;
    }
    public Lugar getLugar(){
        return unLugar;
    }
}
