
public class Auto
{
    private int x;
    private Volante volante;
    private Rueda ruedas;
    private Motor motor;
    private Asiento asientos;
    private Puerta puertas;
    private Chasis chasis;
}
