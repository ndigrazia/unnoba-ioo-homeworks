
public class Tecnico extends Rol{
    private String titulo;
    private double monto;
    
    public Tecnico(String titulo, double monto){
        setTitulo(titulo);
        setMonto(monto);
    }
    
    public double calcularSalario(int antiguedad){
        return monto;
    }
    
    public void setTitulo(String titulo){this.titulo = titulo;}
    public void setMonto(double monto){this.monto = monto;}
    
    public String getTitulo(){return titulo;}
    public double getMonto(){return monto;}
}