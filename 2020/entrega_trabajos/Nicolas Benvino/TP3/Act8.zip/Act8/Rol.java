
public abstract class Rol{
    
    public abstract double calcularSalario(int antiguedad);
    
}