
import java.util.Date;
import java.util.Calendar;

public class Empleado extends Persona{
    private Rol rol;
    private int id;
    private Date fechaIngreso;
    
    public Empleado(String nombre, String direccion, Date fechaNacimiento, long dni, int sexo, Rol rol, int id, Date fechaIngreso){
        super(nombre, direccion, fechaNacimiento, dni, sexo);
        setRol(rol);
        setID(id);
        setFechaIngreso(fechaIngreso);
    }
    
    public double calcularSalario(){
        return rol.calcularSalario(antiguedad());
    }
    
    public int antiguedad() {
        long ingreso = getFechaIngreso().getTime();
        long hoy  = Calendar.getInstance().getTime().getTime();
        return (int)(hoy - ingreso)/86400000;
    }
    
    public void setRol(Rol rol){this.rol = rol;}
    public void setID(int id){this.id = id;}
    public void setFechaIngreso(Date fechaIngreso){this.fechaIngreso = fechaIngreso;}
    
    public Rol getRol(){return rol;}
    public int getID(){return id;}
    public Date getFechaIngreso(){return fechaIngreso;}
}