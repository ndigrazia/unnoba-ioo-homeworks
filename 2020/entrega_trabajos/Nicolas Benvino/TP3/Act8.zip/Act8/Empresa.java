
import java.util.List;
import java.util.ArrayList;

public class Empresa{
    private List<Empleado> empleados = new ArrayList<Empleado>();
    
    public double montoTotal(){
        double montoTotal = 0;
        for (Empleado empleado : empleados)
            montoTotal += empleado.calcularSalario();
        return montoTotal;
    }
    
    public void addEmpleado(Empleado empleado){empleados.add(empleado);}
    public void removeEmpleado(Empleado empleado){empleados.remove(empleado);}
    
    public List<Empleado> getEmpleados(){return empleados;}
}