
import java.util.Date;

public class Persona{
    public static int NO_DEFINIDO = 0;
    public static int MASCULINO = 1;
    public static int FEMENINO = 2;
    
    private String nombre, direccion;
    private Date fechaNacimiento;
    private long dni;
    private int sexo;
    
    public Persona(String nombre, String direccion, Date fechaNacimiento, long dni, int sexo){
        setNombre(nombre);
        setDireccion(direccion);
        setFechaNacimiento(fechaNacimiento);
        setDni(dni);
        setSexo(sexo);
    }
    
    public void setNombre(String nombre){this.nombre = nombre;}
    public void setDireccion(String direccion){this.direccion = direccion;}
    public void setFechaNacimiento(Date fechaNacimiento){this.fechaNacimiento = fechaNacimiento;}
    public void setDni(long dni){this.dni = dni;}
    public void setSexo(int sexo){this.sexo = sexo;}
    
    public String getNombre(){return nombre;}
    public String getDireccion(){return direccion;}
    public Date getFechaNacimiento(){return fechaNacimiento;}
    public long getDni(){return dni;}
    public int getSexo(){return sexo;}
}