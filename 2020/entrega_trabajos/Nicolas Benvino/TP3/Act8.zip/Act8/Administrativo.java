
public class Administrativo extends Rol{
    private int categoria;
    
    public Administrativo(int categoria){
        setCategoria(categoria);
    }
    
    public double calcularSalario(int antiguedad){
        return antiguedad * categoria;
    }
    
    public void setCategoria(int categoria){this.categoria = categoria;}
    
    public int getCategoria(){return categoria;}
}