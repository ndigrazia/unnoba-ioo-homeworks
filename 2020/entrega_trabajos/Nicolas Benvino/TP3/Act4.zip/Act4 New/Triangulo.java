
public class Triangulo extends Figura{
    private double base, altura;
    
    public Triangulo(int color, double base, double altura){
        super(color);
        setBase(base);
        setAltura(altura);
    }
    
    public void pintar(int color){
        setColor(color);
        System.out.println("Pintando triangulo " + color);
    }
    public double area(){
        return (base*altura)/2;
    }
    
    public void setBase(double base){this.base = base;}
    public void setAltura(double altura){this.altura = altura;}
    public double getBase(){return base;}
    public double getAltura(){return altura;}
}