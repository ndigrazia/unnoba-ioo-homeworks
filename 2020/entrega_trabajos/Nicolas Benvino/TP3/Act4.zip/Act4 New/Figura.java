
public abstract class Figura{
    public static int ROJO = 0;
    public static int AMARILLO = 1;
    public static int AZUL = 2;
    public static int NEGRO = 3;
    
    private int color;
    
    public Figura(int color){
        setColor(color);
    }
    
    public void setColor(int color){
        this.color = color;
    }
    public int getColor(){
        return color;
    }
    
    public abstract void pintar(int color);
    public abstract double area();
}