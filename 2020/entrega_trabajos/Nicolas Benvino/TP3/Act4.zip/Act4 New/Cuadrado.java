
public class Cuadrado extends Figura{
    private double largo;
    
    public Cuadrado(int color, double largo){
        super(color);
        setLargo(largo);
    }
    
    public double area(){
        return Math.pow(largo, 2);
    }
    public void pintar(int color){
        setColor(color);
        System.out.println("Pintando cuadrado " + color);
    }
    
    public void setLargo(double largo){this.largo = largo;}
    public double getLargo(){return largo;}
}