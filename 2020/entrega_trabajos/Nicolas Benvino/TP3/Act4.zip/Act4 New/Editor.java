
import java.util.List;
import java.util.ArrayList;

public class Editor{
    private List<Figura> figuras = new ArrayList<Figura>();
    
    public void pintar(int color){
        for (Figura f : figuras)
            f.pintar(color);
    }
    
    public double area(){
        double total = 0;
        for (Figura f : figuras)
            total += f.area();
        return total;
    }
}