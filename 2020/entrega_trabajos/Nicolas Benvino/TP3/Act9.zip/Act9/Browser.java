
import java.util.List;
import java.util.ArrayList;

public class Browser{
    private List<PaginaWeb> historial = new ArrayList<PaginaWeb>();
    private List<String> favoritos = new ArrayList<String>();
    private PaginaWeb paginaActual;
    
    public void addPaginaHistorial(PaginaWeb pagina){
        getHistorial().add(pagina);
    }
    public void removePaginaHistorial(PaginaWeb pagina){
        getHistorial().remove(pagina);
    }
    
    public void addPaginaFavorito(String direccionWeb){
        getFavoritos().add(direccionWeb);
    }
    public void removePaginaFavorito(String direccionWeb){
        getFavoritos().remove(direccionWeb);
    }
    
    public void setPaginaActual(PaginaWeb paginaActual){
        this.paginaActual = paginaActual;
        addPaginaHistorial(getPaginaActual());
    }
    
    public PaginaWeb getPaginaActual(){return paginaActual;}
    public List<PaginaWeb> getHistorial(){return historial;}
    public List<String> getFavoritos(){return favoritos;}
}