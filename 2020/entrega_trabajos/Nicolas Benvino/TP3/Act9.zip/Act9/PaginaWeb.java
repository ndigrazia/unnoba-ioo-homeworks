
import java.util.Date;

public class PaginaWeb{
    private String direccionWeb, HTML;
    private int tamaño;
    private Date fechaVisita;
    
    public PaginaWeb(String direccionWeb, String HTML, int tamaño, Date fechaVisita){
        setDireccionWeb(direccionWeb);
        setHTML(HTML);
        setTamaño(tamaño);
        setFechaVisita(fechaVisita);
    }
    
    public void setDireccionWeb(String direccionWeb){this.direccionWeb = direccionWeb;}
    public void setHTML(String HTML){this.HTML = HTML;}
    public void setTamaño(int tamaño){this.tamaño = tamaño;}
    public void setFechaVisita(Date fechaVisita){this.fechaVisita = fechaVisita;}
    
    public String getDireccionWeb(){return direccionWeb;}
    public String getHTML(){return HTML;}
    public int getTamaño(){return tamaño;}
    public Date getFechaVisita(){return fechaVisita;}
}