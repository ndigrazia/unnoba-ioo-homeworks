import java.util.Date;

public class CuentaBancaria
{
    
    // atributos descriptivos
    final Date fechaDeCreación = new Date(); //fecha de creacion asignada al crear el objeto
    private String titular ="Sin Asignar"; //por este ejercicio se usa String pero deberia ir una clase Persona
    
    // atributos funcionales
    private boolean activada = false; //cuenta desactivada por defecto
    private float saldo = 0; //saldo en la cuenta
    private int máximoExtracciones; //maximo de extracciones que puede  realizar

    //operaciones
    
    public void activarCuenta(){
         activada = true;
    }
    
    public void desactivarCuenta(){
         activada = false;
    }
    
    //getters y setters
    public String getFechaCreacion(){
    return fechaDeCreación.toString();
    }
    
    public String getTitular(){
    return titular;
    }
    
    public float getSaldo(){
    return saldo;
    }

    public int getExtraccionesRestantes(){
    return máximoExtracciones;
    }

    public void setMaximoExtracciones(int nuevoMaximo){
        máximoExtracciones = nuevoMaximo;
    }
    
    public void setTitular(String nuevoTitular){
        titular = nuevoTitular;
    }
    
    public String depositar(float deposito){
        if(activada){
            saldo+=deposito;
            return "Deposito con exito";
        }
        return "La cuenta no esta activada";
    }
    
    public String retirar(float retiro){
        if ( (saldo-retiro) > 0 && máximoExtracciones>0 && activada){
            saldo -= retiro;
            máximoExtracciones--;
            return "Retiro con Exito";
        }
        return "No se pudo retirar";
    }
    
}
