public class reproductorMp3
{

    // atributo funcional
    private boolean encendido = false; //dispositivo entendido
    private boolean reproduciendo = false; //reproduciendo cancion
    private int cancionActual = 0; //numero de cancion actual (para una lista)
    private int canciones = 0; //numero de canciones en la lista
    private int volumen= 0; //volumen

    
    //operaciones
    
    
    public void prender(){
        encendido = true;
    }
    
    public void apagar(){
        encendido = false;
        reproduciendo = false;
    }
    
    public void reproducir(){
        if (encendido)
            reproduciendo = true;
    }
    
    public void pausar(){
        cancionActual = 0;
        reproduciendo = false;
    }
    
    public void siguiente(){
        if (cancionActual < canciones)
            cancionActual++;
    }
    
    public void anterior(){
        if (cancionActual > 1)
            cancionActual--;
    }
    
    public void agregarCancion(){
        canciones++;
    }
    
    public void sacarCancion(){
        if (canciones > 0)
            canciones--;
    }
    
    public void subirvolumen(){
        if (volumen<100)
            volumen++;
    }
    
    public void bajarvolumen(){
        if (volumen>0)
            volumen--;
    }
    
    //getter-setter

    private boolean encendido(){
        return encendido;
    }
    
    private boolean reproduciendo(){
        return reproduciendo;
    }
    
    private int cancionActual(){
        return cancionActual;
    }
    
}
