public class AireAcondicionado
{
    // atributos descriptivos
    private int temperaturaMinima = 0;
    private int temperaturaMaxima = 30;
    // atributos funcionales
    private int temperatura = 24;
    private boolean encendido = false;
    
    //operaciones
    public void encender(){
        encendido = true;
    }

    public void apagar(){
        encendido = false;
    }
    
    public void subirTemperatura(){
        temperatura++;
    }

    public void bajarTemperatura(){
        temperatura--;
    }
    
    //getters y setters
    public boolean encendido(){
        return encendido;
    }
    
    public int getTemperatura(){
        return temperatura;
    }
    
}
