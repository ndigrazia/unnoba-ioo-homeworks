
/**
 * Write a description of class Aireacondicionado here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class AireAcondicionado
{
   
    private boolean encendido= false;
    private int temperatura;
    private int tempmaxima;
    
 
    
        public void encender (){
            
            encendido= true;
            }
        public void apagar(){
            
            encendido= false;
        }    
        
        public void subirtemp (){
            
            if (temperatura < tempmaxima)
                temperatura++;
            
        }
        
        public void bajartemp(){
            
            if (temperatura > 0)
                temperatura--;
        
        }
        
        public int gettempmaxima(){
            
            return tempmaxima;
        }
        
        public void settempmaxima(int temp){
            
            tempmaxima = temp;
            
        }
        
        public int gettempactual(){
            
            return temperatura;
            
        }
        
    }
        