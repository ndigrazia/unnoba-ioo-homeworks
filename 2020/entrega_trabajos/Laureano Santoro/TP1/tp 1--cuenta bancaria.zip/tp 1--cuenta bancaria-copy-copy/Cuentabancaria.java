
/**
 * Write a description of class Cuentabancaria here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Cuentabancaria 
{
   private String titular;
   private int saldo;
   private int maximoextracciones;
   private int fechacreacion;
   
   
   
    
   public String gettitular(){
        
        return titular;
        
        }
   public void settitular(String nombre) {
        
        titular = nombre;
        
        }
   public int getSALDO() {
   
        return saldo;
    
    }
    
   public void setSALdo (int numero){
        
        saldo = numero;
    
    
    }
    
   public int getmaxextracciones() {
        
        return maximoextracciones;
    
    }
    
   public void setmaxextracciones(int maximo){
        
        maximoextracciones = maximo;
    
    
    
    }
    
    
    
    
}
