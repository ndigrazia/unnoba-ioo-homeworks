
public class Circulo
{
    private double radio;
    private Punto centro;

    public Circulo(Punto micentro, double miradio){
        radio=miradio;
        centro=micentro;
    }

    public void ampliar (int unValor){
        radio+=unValor;
    }
   
    public double area(){
        return Math.PI * Math.pow(radio, 2);
    }
    public void trasladar(int x, int y){
        trasladar(new Punto(x,y));
    }
    
    public  void trasladar(Punto spunto){
        centro.sumarPunto(spunto);
       
    }
    
        
    
    
}
