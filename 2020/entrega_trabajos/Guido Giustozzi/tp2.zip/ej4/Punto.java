

public class Punto
{
     private int x;
     private int y;
    
     public Punto(int x, int y){
        this.x=x;
        this.y=y;
    }
    
    public void sumarValor(int valor){
        x=+valor;
        y=+valor;
    }
    
    public void sumarPunto(Punto unPunto){
        x=x+unPunto.x;
        y=y+unPunto.y;
    }
    
    
    public double distanciaDe(Punto unPunto){
        double x2=unPunto.x;
        double y2=unPunto.y;
        double dentro=(Math.pow((x2-this.x), 2))+(Math.pow((y2-this.y), 2));
        double a=Math.sqrt(dentro);
        return a;
    }
    public double DistanciaAlorigen(){
        double dentro=(Math.pow((this.x), 2))+(Math.pow((this.y), 2));
        double a=Math.sqrt(dentro);
        return a;
    }
    
    public void setX(int X){
        x=X;
    }
    public int getX(){
        return x;
    }
    
    public void setY(int Y){
        y=Y;
    }
    public int getY(){
        return y;
    }
    

    
}
