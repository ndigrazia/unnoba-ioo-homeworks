import java.util.List;
import java.util.ArrayList;


public class Auto
{
   
   private Ruedas[] ruedas= new Ruedas[4];
   private Motor motor;
   private Puertas[] puertas= new Puertas[4];
   private Volante volante;
  
   
  
   public Auto(){ 
    }
    
    public Motor getMotor(){
        return motor;
    }
    public void setMotor(Motor motor){
        this.motor=motor;
    }
    
    public Volante getVolante(){
        return volante;
    }
    public void setMotor(Volante volante){
        this.volante=volante;
    }
    
    public void addRuedas(Ruedas rueda, int pos){
        ruedas[pos]=rueda;
    }
    
    public Ruedas getRueda(int pos) {
        return ruedas[pos];
    }
    
    public void addPuertas(Puertas puerta, int pos){
        puertas[pos]=puerta;
    }
    
    public Puertas getPuertas(int pos) {
        return puertas[pos];
    }
}
