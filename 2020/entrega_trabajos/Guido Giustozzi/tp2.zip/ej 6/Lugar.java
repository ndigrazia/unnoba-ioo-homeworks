

public class Lugar
{
   
    private String nombreLugar;
    
    public Lugar(String lugar){
        this.nombreLugar=lugar;
    }
    public Lugar(){
    }
    
    public void setLombre(String nombreLugar) {
        this.nombreLugar = nombreLugar;
    }
    public String getNombre() {
        return nombreLugar;
    }

   
}
