

public class Persona
{
    private String Nombre;
    private int Edad;
    
    public Persona(String nombre, int edad){
        this.Nombre=nombre;
        this.Edad=edad;
    }
    public Persona()
    {
    }

    public void setNombre(String nombre) {
        this.Nombre = nombre;
    }
    public String getNombre() {
        return Nombre;
    }
    

    public void setEdad(int Edad) {
        this.Edad = Edad;
    }
    public int getEdad() {
        return Edad;
    }
    

}
