import java.util.Date;

public class Cita
{
    private int Importancia;
    private Persona Contacto1;
    private Persona Contacto2;
    private Lugar unLugar;
    private Date Fecha;
    
    public Cita(int Importancia, Persona Contacto1,Persona Contacto2, Lugar unLugar1, Date Fecha1){
        this.Importancia=Importancia;
        this.Contacto1=Contacto1;
        this.Contacto2=Contacto2;
        this.unLugar=unLugar1;
        this.Fecha=Fecha1;
    }
    public Cita (){
    }
    
    public Lugar getunLugar() {
        return unLugar;
    }
    public void setLugar(Lugar lugar) {
       this.unLugar = lugar;
    }
    
     public Date getFecha() {
        return Fecha;
    }
    public void setFecha(Date fecha) {
       this.Fecha = fecha;
    }

    public Persona getContacto1() {
        return Contacto1;
    }
    public void setContactoOrigen(Persona contacto) {
       this.Contacto1 = contacto;
    }

    public Persona getContacto2() {
        return Contacto2;
    }
    public void setContacto2(Persona contacto) {
       this.Contacto2 = contacto;
    }
    
    public int getImportancia() {
        return Importancia;
    }
    public void setImportancia(int importancia) {
       this.Importancia = importancia;
    }
    
    
    
    
    
    
    
    

    
}
