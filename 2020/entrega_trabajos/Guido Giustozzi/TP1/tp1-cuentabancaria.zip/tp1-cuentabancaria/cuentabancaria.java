

public class cuentabancaria
{
    private String titular;
    private int saldo;
    private int MaxExtracciones;
    private String fechacreacion;
    
    public void RetirarPlata(int plata){
        saldo=saldo-plata;
    }
    public void DepositarPlata(int plata){
        saldo=saldo+plata;
    }
    
    public String gettitular(){
        return titular;
    }
    
    public void settitular(String titu){
        titular=titu;
    }
    
    public int getsaldo(){
        return saldo;
    }
    public void setsaldo(int sald){
        saldo=sald;
    }
    
    public int getMaxExtracciones(){
        return MaxExtracciones;
    }
    public void setMaxExtracciones(int max){
        MaxExtracciones=max;
    }
    
    public String getfechacreacion(){
        return fechacreacion;
    }
    public void setfechacreacion(String fecha){
        fechacreacion=fecha;
    }
    
    
    
}
