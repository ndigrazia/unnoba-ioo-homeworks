
public class mp3
{
   private int volumen=0;
   private boolean encendido=false;
   private boolean reproducioendo=false;
   private int cancion =1;
   
   public void Encender (){
       encendido=true;
    }
   public void Apagar(){
       encendido=false;
    }
   public void SubirVolumen(){
       if (volumen <10) {
        volumen++; }
    }
   public void BajarVolumen(){
       if (volumen >0){
        volumen--;}
    }
    
   public void Reproducir (){
       reproducioendo=true;
    }
   public void Pausar(){
       reproducioendo=false;
    }
    
   public void PasarSigCancion(){
       cancion++;
       if (cancion>100){
           cancion=1;}
        }
   public void VolverAtasCancion(){
       cancion--;
       if (cancion>1){
           cancion=1;}
        }
    }