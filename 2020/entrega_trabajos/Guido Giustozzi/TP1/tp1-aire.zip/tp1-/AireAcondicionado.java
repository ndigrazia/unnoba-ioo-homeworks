
public class AireAcondicionado
{
    private boolean encendido= false;
    private int temperaturaactual=24;
    private boolean antihumedad=false;
    
     
    public void encender(){
        encendido=true;
    }
    public void apagar(){
        encendido=false;
    }
    public void subirtemperatura(){
        temperaturaactual++;
    }
    public void bajarTemperatura(){
        temperaturaactual--;
    }
    public void antihumedadOn(){
        antihumedad=true;
    }
    public void antihumedadOff(){
       antihumedad=true;
    }
    }

