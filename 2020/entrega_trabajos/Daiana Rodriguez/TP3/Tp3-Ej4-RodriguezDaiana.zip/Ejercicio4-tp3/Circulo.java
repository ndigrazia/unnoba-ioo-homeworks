public class Circulo extends Figura{
    private double radio;
    
    public Circulo(int color){
        super(color);
    }
    
    public double area(){
        return Math.PI * Math.pow(radio,2);
    }
    public void pintar(int color){
        setColor(color);
        System.out.println("Pintando circulo" + color);
    }
    
    public void setRadio(double radio){
        this.radio = radio;
    }
    public double getRadio(){
        return radio;
    }
    
}
