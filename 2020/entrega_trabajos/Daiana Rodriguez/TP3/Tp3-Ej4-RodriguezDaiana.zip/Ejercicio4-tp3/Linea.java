public class Linea extends Figura {
    private double largo;
    
    public Linea (int color, double largo){
        super(color);
        setLargo(largo);
    }
    
    public double area(){
        return 0;
    }
    public void pintar(int color){
        setColor(color);
        System.out.println("Pintando linea" + color);
    }
    
    public void setLargo(double largo){
        this.largo = largo;
    }
    public double getLargo(){
        return largo;
    }
}
