public abstract class Figura{
    public static int ROJO = 0, AMARILLO = 1, AZUL = 2, NEGRO = 3;
    
    public int color;
    
    public Figura(int color){
        setColor(color);
    }
    
    public void setColor(int color){
        this.color=color;
    }
    public int getColor(){
        return color;
    }
    
    public abstract void pintar(int color);
    public abstract double area();
}
