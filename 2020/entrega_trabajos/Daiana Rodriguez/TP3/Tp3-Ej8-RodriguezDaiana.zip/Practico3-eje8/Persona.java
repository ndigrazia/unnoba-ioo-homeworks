import java.util.Date;

public class Persona {
    public static int MASCULINO = 0;
    public static int FEMENINO = 1;
    
    protected String nombre, DNI, direccion;
    protected Date fechaNacimiento;
    protected int sexo;   
    
    public Persona(String nombre, String DNI, String direccion, Date fechaNacimiento, int sexo){
        this.nombre = nombre;
        this.DNI = DNI;
        this.direccion = direccion;
        this.fechaNacimiento = fechaNacimiento;
        this.sexo = sexo;
    }
    
    public void setNombre(String miNombre){
        this.nombre = miNombre;
    }
    public String getNombre(){
        return this.nombre;
    }
    
    public void setDNI(String miDNI){
        this.DNI = miDNI;
    }
    public String getDNI(){
        return DNI;
    }
    
    public void setDireccion(String miDireccion){
        this.direccion = miDireccion;
    }
    public String getDireccion(){
        return direccion;
    }
    
    public void setFechaNacimiento(Date fechaNacimiento){
        this.fechaNacimiento = fechaNacimiento;
    }
    public Date getFechaNacimiento(){
        return fechaNacimiento;
    }
    
    public void setSexo(int sexo){
        this.sexo = sexo;
    }
    public int getSexo(){
        return sexo;
    }
}
