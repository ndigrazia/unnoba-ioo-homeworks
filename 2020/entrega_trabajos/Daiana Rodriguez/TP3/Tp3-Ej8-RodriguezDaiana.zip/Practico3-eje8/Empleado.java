import java.util.Date;
import java.util.Calendar;

public class Empleado extends Persona{   
    private int id;
    
    private Rol rol;
    private String titulo;
    private Date fechaIngreso;
    
    public Empleado(String nombre, String DNI, String direccion, Date fechaNacimiento, int sexo, int id, Rol rol, String titulo, Date fechaIngreso){
        super(nombre, DNI, direccion, fechaNacimiento, sexo);
        this.id = id;
        this.rol = rol;
        this.titulo = titulo;
        this.fechaIngreso = fechaIngreso;

    }
   
    public void setId(int id){
        this.id = id;
    }
    public int getId(){
        return id;
    }

    public void setRol(Rol rol){
        this.rol = rol;
    }
    public Rol getRol(){
        return rol;
    }
    
    public void setTitulo(String titulo){
        this.titulo = titulo;
    }
    public String getTitulo(){
        return titulo;
    }
    
    public void setFechaIngreso(Date fechaIngreso){
        this.fechaIngreso = fechaIngreso;
    }
    public Date getFechaIngreso(){
        return fechaIngreso;
    }
    
    public double calcularSalario(){
        return rol.calcularSalario(this);
    }
    
    public int antiguedad(){
        long ingreso = fechaIngreso.getTime();
        long hoy = Calendar.getInstance().getTime().getTime();
        
        return (int)(hoy - ingreso) / 86400000;
    }
}
