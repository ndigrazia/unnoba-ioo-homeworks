import java.util.List;
import java.util.ArrayList;

public class Empresa{
    private List<Empleado> empleados = new ArrayList<Empleado>();
    private String nombreEmpresa;
    public Empresa(String nombreEmpresa){
        this.nombreEmpresa = nombreEmpresa;
    }

    public void agregarEmpleado(Empleado miEmpleado){
        empleados.add(miEmpleado);
    }
    public void eliminarEmpleado(Empleado miEmpleado){
        empleados.remove(miEmpleado);
    }
    public double montoTotal(){
        double total = 0;
        for(Empleado miEmpleado : empleados){
            total+=miEmpleado.calcularSalario();
        }
        return total;
    }
    
    public void setNombreEmpresa(String miEmpresa){
        this.nombreEmpresa = miEmpresa;
    }
    public String getNombreEmpresa(){
        return nombreEmpresa;
    }
}
