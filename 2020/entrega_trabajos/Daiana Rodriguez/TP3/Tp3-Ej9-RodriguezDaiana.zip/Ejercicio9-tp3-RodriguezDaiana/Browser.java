import java.util.List;
import java.util.ArrayList;

public class Browser
{
    private Pagina paginaActual;
    private List<Pagina> historial = new ArrayList<Pagina>();
    private List<String> favoritos = new ArrayList<String>();
    
    public Browser(Pagina paginaActual){
        this.paginaActual = paginaActual;
    }
    
    public void setPaginaActual(Pagina miPagina){
        this.paginaActual = miPagina;
    }
    public Pagina getPaginaActual(){
        return paginaActual;
    }
    
    public void agregarPaginaHistorial(Pagina pagina){
        historial.add(pagina);
    }
    
    public void eliminarPagina(Pagina pagina){
        historial.remove(pagina);
    }
    
    public Pagina verUltimaPagina(){
        return historial.get(cantidadPaginasVisitadas()-1);
    }
    
    public int cantidadPaginasVisitadas(){
        return historial.size();
    }
    
    public void agregarPaginaFavoritos(String direccionWeb){
        favoritos.add(direccionWeb);
    }
    
}
