import java.util.Date;

public class Pagina
{
    private String direccionWeb;
    private Date fechaDeVisita;
    private int tamaño;
    private String codigoHTML;
    
    public Pagina(String direccionWeb, Date fechaDeVisita, int tamaño, String codigoHTML){
        this.direccionWeb = direccionWeb;
        this.fechaDeVisita = fechaDeVisita;
        this.tamaño = tamaño;
        this.codigoHTML = codigoHTML;
    }
    
    public void setDireccionWeb(String miDireccion){
        this.direccionWeb = miDireccion;
    }
    public String getDireccionWeb(){
        return direccionWeb;
    }
    
    public void setFechaVisitada(Date miFecha){
        this.fechaDeVisita = miFecha;
    }
    public Date getFechaVisitada(){
        return fechaDeVisita;
    }
    
    public void setTamaño(int miTamaño){
        this.tamaño = miTamaño;
    }
    public int getTamaño(){
        return tamaño;
    }
    
    public void setCodigoHTML(String miCodigo){
        this.codigoHTML = miCodigo;
    }
    public String getCodigoHTML(){
        return codigoHTML;
    }

}
