//Daiana Rodriguez
public class ReproductorMP3
{
    //Atributos descriptivos
    private String marca;
    
    //Atributos funcionales
    private boolean encendido=false;
    private int cancionActual,cantidadCanciones,volMin=0,volMax=100,volActual;
    
    //Operaciones
       public void encender(){
           encendido=true;
           volActual=50;
        }
       public void apagar(){
           encendido=false;
           volActual=0;
        }
        
       public void pasarCancion(){
           if(encendido==true && cantidadCanciones > cancionActual){
               cancionActual++;
            }
        } 
        public void cancionAnterior(){
            if(encendido == true && cancionActual > 0){
                cancionActual--;
            }
        }
        public void bajarVolumen(){
            if(encendido == true && volActual > volMin) {
                volActual--;
            }
        }
        public void subirVolumen(){
            if(encendido == true && volActual < volMax){
                volActual++;
            }
        }
        
    //Setters y Getters
    public void setMarca(String marcaProducto){
        marca=marcaProducto;
    }
    public String getMarca(){
        return marca;
    }
    
    public void setCantCanciones(int cantidadDeCanciones){
        cantidadCanciones=cantidadDeCanciones;
    }
    public int getCantidadCanciones(){
        return cantidadCanciones;
    }
    
    public int getCancionActual(){
        return cancionActual;
    }
   
}
