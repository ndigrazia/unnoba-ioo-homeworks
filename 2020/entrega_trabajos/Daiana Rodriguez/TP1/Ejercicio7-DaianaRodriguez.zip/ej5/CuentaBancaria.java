
/*
 * Daiana Rodriguez
 */
public class CuentaBancaria
{
   //Atributos descriptivos
   private String titular, tipoCuenta;
   private float saldo;
   private int maxExt, fechaCreacion, numTarjeta;
   
   //Atributos funcionales
   private int extActual;
   private float deposito;
   
   //Operaciones
   public void depositar(int deposito){
       saldo+=deposito;
    }
   public void extraer(int extraccion){
        if(extraccion <= maxExt && saldo-extraccion >= 0){
            saldo-=extraccion;
        }
    }
   
   //Setters y Getters
   public void setTitular( String titularCuenta){
       titular=titularCuenta;
    }
   public String getTitular(){
       return titular;
    }
    
    public void setTipoCuenta( String tipoDeCuenta){
       tipoCuenta=tipoDeCuenta;
    }
    public String getTipoCuenta(){
       return tipoCuenta;
    }
    
    public void setSaldo( float Saldo ){
       saldo=Saldo;
    }
    public float getSaldo(){
       return saldo;
    }
    
    public void setMaxExt(int maximaExtraccion){
        maxExt=maximaExtraccion;
    }
    public int getMaximaExtraccion(){
        return maxExt;
    }
    
    public void setFechaCreacion(int fechaDeCreacion){
        fechaCreacion=fechaDeCreacion;
    }
    public int getFechaCreacion(){
        return fechaCreacion;
    }
    
    public void setNumTarjeta(int numeroTarjeta){
        numTarjeta=numeroTarjeta;
    }
}
