
/*
 Daiana Rodriguez
 */
public class AireAcondicionado
{
   //Atributos descriptivos
   private String marca;
   private int temperaturaMax, temperaturaMin;
   
   //Atributos funcionales
   private int tempActual;
   private boolean encendido=false, calorOFrio=false, turbo=false;
    /* calorOFrio --> hago referencia al boton de cambiar de un estado a otro.
     false lo tomo como frio y true como calor. */
     
   //Operacioness
   public void encender(){
       encendido=true;
       tempActual=24;
    }
   public void apagar(){
       encendido=false;
       tempActual=0;
    }
   public void subirTemperatura(){
       if(tempActual < temperaturaMax && encendido==true ){
           tempActual++;
        }
    }
   public void bajarTemperatura(){
       if(tempActual > temperaturaMin && encendido == true){
           tempActual--;
        }
    }
   public void opcionCalor(){
       calorOFrio=true;
    }
   public void opcionFrio(){
       calorOFrio=false;
    }
   public void prenderTurbo(){
       turbo=true;
    }
   
    //Setters y Getters
    public boolean getEncendido(){
        return encendido;
    }
    
    public boolean getOperacionCalorFrio(){
        return calorOFrio;
    }
    
    public boolean getTurbo(){
        return turbo;
    }
    
    public void setMarca(String marcaProducto){
        marca=marcaProducto;
    }
    public String getMarca(){
        return marca;
    }
    
    public void setTempMax(int temperaturaMaxima){
        temperaturaMax=temperaturaMaxima;
    }
    public int getTempMax(){
        return temperaturaMax;
    }
    
    public void setTempMin(int temperaturaMinima){
        temperaturaMin=temperaturaMinima;
    }
    public int getTempMin(){
        return temperaturaMin;
    }
    
}
