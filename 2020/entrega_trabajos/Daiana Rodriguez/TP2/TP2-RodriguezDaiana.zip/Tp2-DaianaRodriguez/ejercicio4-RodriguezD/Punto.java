public class Punto
{
    /**
     * Atributos descriptivos
     */
    private int x,y;
    
    /**
     * Constructor defecto
     */
    public Punto(int x, int y) {
        this.x = x;
        this.y = y;
    }
    
    public Punto() {
        this(0,0);
    }
    
    public void sumarValor(int unValor){
        x+=unValor;
        y+=unValor;
    }
    
    public void sumarPunto(Punto unPunto){
        x+=unPunto.getX();
        y+=unPunto.getY();
    }
    
    public double distanciaDe(Punto unPunto){
        double radicando = Math.pow(unPunto.getX() - x, 2) + Math.pow(unPunto.getY() - y, 2);
        return Math.sqrt(radicando);
    }
    
    public double distanciaAlOrigen(){
        return distanciaDe(new Punto());
    }
    
    /**
     * Setters y Getters
     */
    public void setX(int miX){
        x=miX;
    }
    public int getX(){
        return x;
    }
    
    public void setY(int miY){
        y=miY;
    }
    public int getY(){
        return y;
    }
    

}
