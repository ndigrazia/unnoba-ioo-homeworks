public class Circulo
{
    /**
     * Atributos descriptivos
     */
    private Punto centro;
    private double radio;
    
    public Circulo (Punto miCentro, double miRadio){
        centro = miCentro;
        radio = miRadio;
    }
    
    public void ampliar(int unValor){
        radio += unValor;
    }
    
    public double area(){
        return Math.PI * Math.pow(radio, 2);
    }
    
    public void trasladar(int x, int y){
        trasladar(new Punto(x, y));
    }
    
    public void trasladar(Punto miPunto) {
        centro.sumarPunto(miPunto);
    }
    
}
