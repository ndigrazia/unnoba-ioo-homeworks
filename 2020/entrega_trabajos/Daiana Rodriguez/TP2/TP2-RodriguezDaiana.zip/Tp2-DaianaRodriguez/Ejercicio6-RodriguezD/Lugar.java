public class Lugar
{
    /**
     * Atributos descriptivos
     */
    private String calleLugar, descripcion;
    private int numLugar;
    
    /**
     * Constructor defecto
     */
    public Lugar (String calle, int num, String desc){
        this.calleLugar=calle;
        this.numLugar=num;
        this.descripcion=desc;
    }
    
    /**
     * Setter y Getters
     */
    
    public void setCalle(String miCalle){
        this.calleLugar = miCalle;
    }
    public String getCalle(){
        return calleLugar;
    }
    
    public void setNumero(int miNum){
        this.numLugar = miNum;
    }
    public int getNumero(){
        return numLugar;
    }
    
    public void setDescripcion(String miDescripcion){
        this.descripcion = miDescripcion;
    }
    public String getDescripcion(){
        return descripcion;
    }
}
