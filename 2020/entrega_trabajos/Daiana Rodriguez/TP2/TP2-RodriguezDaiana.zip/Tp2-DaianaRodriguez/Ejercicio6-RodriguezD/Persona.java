public class Persona
{
    /**
     * Atributos descriptivos
     */
    private String nombre, apellido, DNI;
    private double altura, peso;
    /**
     * Constructor defecto
     */
    public Persona(String nombre, String apellido, String DNI, double altura, double peso){
        this.nombre = nombre;
        this.apellido = apellido;
        this.DNI = DNI;
        this.altura = altura;
        this.peso = peso;
    }
    
    /**
     * Setters y Getters
     */
    public void setNombre(String miNombre){
        this.nombre = miNombre;
    }
    public String getNombre(){
     return nombre;
    }
    
    public void setApellido(String miApellido){
        this.apellido = apellido;
    }
    public String getApellido(){
     return apellido;
    }
    
    public void setDni(String dni){
        this.DNI = dni;
    }
    public String getDni(){
     return DNI;
    }
    
    public void setAltura(double miAltura){
        this.altura = miAltura;
    }
    public double getAltura(){
     return altura;
    }
    
    public void setPeso(double miPeso){
        this.peso = miPeso;
    }
    public double getPeso(){
     return peso;
    }
}
