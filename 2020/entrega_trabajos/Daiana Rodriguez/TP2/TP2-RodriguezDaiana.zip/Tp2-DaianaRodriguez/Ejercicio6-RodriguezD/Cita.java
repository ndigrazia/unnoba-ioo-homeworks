import java.util.Date;

public class Cita
{   
    /**
     * Atributos descriptivos
     */
    private Date fecha;
    private Persona origenContacto, destinoContacto;
    private Lugar lugar;
    private int importancia;
    
    /**
     * Constructor defecto
     */
    public Cita(Date fecha, Persona origenContacto, Persona destinoContacto, Lugar lugar, int importancia){
        this.fecha=fecha;
        this.origenContacto=origenContacto;
        this.destinoContacto=destinoContacto;
        this.lugar=lugar;
        this.importancia=importancia;
    }
    
    /**
     * Setters y getters
     */
    public void setFecha(Date miFecha){
        this.fecha = miFecha;
    } 
    public Date getFecha() {
        System.out.println("Fecha: " + fecha);
        return fecha;
    }
    
    public void setOrigenCont(Persona origenMiContacto){
        this.origenContacto = origenMiContacto;
    }
    public Persona getOrigenCont(){
        return origenContacto;
    }
    
    public void setDestContacto(Persona destinoMiContacto){
        this.destinoContacto = destinoMiContacto;
    }
    public Persona getDestContacto(){
        return destinoContacto;
    }
    
    public void setLugar(Lugar miLugar){
        this.lugar = miLugar;
    }
    public Lugar getLugar(){
        return lugar;
    }
    
    public void setImportancia(int miImportancia){
        this.importancia = miImportancia;
    }
    public int getImportancia(){
        return importancia;
    }
}
