public class Motor
{
    private boolean encendido = false;
    /**
     * Constructor defecto
     */
    public Motor(boolean encendido)
    {  
        this.encendido = encendido;
    }
    
    /**
     * Operaciones
     */
   public void encender(){
       encendido = true;
    }
    
   public void apagar() {
       encendido = false;
    }

}
