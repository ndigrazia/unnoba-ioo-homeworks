public class Puerta
{
    /**
     * Atributos descriptivos
     */
    private boolean abrir;
    
    /**
     * Operaciones
     */
    public void abrir(){
        abrir = true;
    }
    
    public void cerrar(){
        abrir = false;
    }
    
    public boolean estadoPuerta(){
        return abrir;
    }
}
