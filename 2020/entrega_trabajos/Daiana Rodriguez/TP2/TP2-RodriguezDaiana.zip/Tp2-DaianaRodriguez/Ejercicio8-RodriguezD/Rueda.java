public class Rueda
{
   private String materialRueda;
   
   public void setMatRueda(String miMaterial){
       this.materialRueda = miMaterial;
    }
    
   public String getMatRueda(){
       return materialRueda;
    }
}
