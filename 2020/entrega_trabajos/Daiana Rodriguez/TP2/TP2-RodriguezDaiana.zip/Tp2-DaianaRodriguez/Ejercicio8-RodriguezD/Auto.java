import java.util.List;
import java.util.ArrayList;

public class Auto
{
    /**
     * Atributos descriptivos
     */
    private String marca, modelo, color, matricula;
    private boolean encendido=false;
    private Motor motor;
    private Puerta[] puertas = new Puerta[4];
    private Rueda[] ruedas = new Rueda[5];
    
    /**
     * Constructor defecto
     */
    public Auto(String marca, String modelo, String color, String matricula, boolean encendido, Motor motor){
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.matricula = matricula;
        this.encendido = encendido;
        this.motor = motor;
    }
    
    /**
     * Operaciones
     */
    public void encender(){
        encendido = true;
    }
    
    public void apagar(){
        encendido = false;
    }
    
    public void encenderMotor(){
        motor.encender();
    }
    
    public void apagarMotor(){
        motor.apagar();
    }
    
    public void cerrarPuertas(){
        for(int x=0 ; x < puertas.length ; x++)
            puertas[x].cerrar();
    }
    
    /**
     * Setters y Getters
     */
    
    public void setMarca(String miMarca){
        this.marca = miMarca;
    }
    public String getMarca(){
        return marca;
    }
    
    public void setModelo(String miModelo){
        this.modelo = miModelo;
    }
    public String getModelo(){
        return modelo;
    }
    
    public void setColor(String miColor){
        this.color = miColor;
    }
    public String getColor(){
        return color;
    }
    
    public void setMatricula(String miMatricula){
        this.matricula = miMatricula;
    }
    public String getMatricula(){
        return matricula;
    }
    
    public void setMotor(Motor miMotor){
        this.motor = miMotor;
    }
    public Motor getMotor(){
        return motor;
    }   
    
    public void addPuerta(Puerta miPuerta, int pos){
        puertas[pos] = miPuerta;
    }
    public Puerta getPuerta(int pos) {
        return puertas[pos];
    }
    
    public void addRueda(Rueda miRueda, int pos){
        ruedas[pos] = miRueda;
    }
    public Rueda getRueda(int pos){
        return ruedas[pos];
    }
    
}
