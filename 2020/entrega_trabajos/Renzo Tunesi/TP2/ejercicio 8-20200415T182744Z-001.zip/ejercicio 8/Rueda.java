public class Rueda
{
    private boolean pinchada;
    
    public Rueda()
    {
    }
    
    public void mirar() {
        pinchada=true;
    }

    public void nomirar() {
        pinchada=false;
    }

    public boolean estaPinchada(){
        return pinchada;
    }
}
