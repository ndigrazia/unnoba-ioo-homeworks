import java.util.List;
import java.util.ArrayList;

public class Auto{
    private String marca;
    
    private Motor motor;
    private Rueda[] ruedas= new Rueda [5];
    private Puerta[] puertas= new Puerta[5];
    
    public Auto()
    {
    }
    
    public void setMotor(Motor motor){
        this.motor=motor;
    }
    
    public Motor getMotor(){
        return motor;
    }
    
    public void addRueda(Rueda rueda, int pos){
         ruedas[pos]=rueda;
        }
    public Rueda getRueda(int pos){
        return ruedas[pos];

    }
    public void addPuerta(Puerta puerta,int pos){
         puertas[pos]=puerta;
        }
    public Puerta getpuerta(int pos){
        return puertas[pos];

    }




}


    
    
