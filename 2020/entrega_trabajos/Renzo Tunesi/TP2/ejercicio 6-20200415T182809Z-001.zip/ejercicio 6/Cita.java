import java.util.Date;

public class Cita
{
    private Date fecha;
    private Persona contacto;
    private Persona destino;
    private int importancia;
    private Lugar unlugar;
    
    public Cita(){
    }
    
    public Date getFecha(Date fecha){
        System.out.println("retorno fecha:" + fecha);
        return fecha;
    }
    
    public void setFecha(Date fecha){
        this.fecha = fecha;
    }
    
    public int getImportanmcia(){
        return importancia;
    }
    
    public void setImportancia(int importancia){
        this.importancia = importancia; 
    }

    public Persona getcontacto(){
        return contacto;
    }
    
    public void setcontacto(Persona cont){
        this.contacto = cont;
    }

    public Persona getDestino(){
        return destino;
    }

    public void setDestino (Persona cont){
        this.destino = cont;
    }

    public Lugar getLugar(){
        return unlugar;
    }
    
    public void setLugar(Lugar fecha){
        this.unlugar = unlugar;
    }
}




