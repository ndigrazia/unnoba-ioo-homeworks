
import java.util.List;
import java.util.ArrayList;

public class Editor
{
  private List<Figura>figuras =new ArrayList<Figura>();
   
  public Editor(){
    }
    
  public void pintar(){
      for(Figura f:figuras){
          f.pintar();
        }
    }
          
  public double calcularArea(){
      double total=0;
      for(Figura f:figuras){
          total+=f.area();
        }
        
        return total;
    }
}