public abstract class Figura
{
    public static final int ROJO = 0;
    public static final int VERDE = 1;
    public static final int GRIS = 2;
    
 private int color;
 
 public Figura(int color){
     this.color=color;
    }
 
 public void setColor(int color){
     this.color=color;
    }
    
 public int getColor(){
     return color;
    }
    
 public abstract void pintar ();
 
 public abstract double area();
}
 