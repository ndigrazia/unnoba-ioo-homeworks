import java.util.List;
import java.util.ArrayList;

public class Empresa
{
    
    private List<Empleado> empleados = new ArrayList<Empleado>();
    
    public Empresa()
    {
    }

      public void agregarEmpleado(Empleado e){
        empleados.add(e);
    }
    
    public void borrarEmpleado(Empleado e){
        empleados.remove(e);
    }

    public double montoTotal() {
        double total = 0;
        
        for(Empleado e:empleados) {
            total+=e.calcularSalario();
        }
        
        return total;
    }
}

   