import java.util.Date;
public class Persona
{
    public static int MASCULINO = 1;
    public static int FEMENINO = 2;
    
    
    private String nombre;
    private int dni;
    private String direccion;
    private Date fechaNacimiento;
    private int sexo;

    
    public Persona()
    {
    }
        
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getNombre() {
        return this.nombre;
    }
    
    public void setDni(int dni) {
        this.dni = dni;
    }
    public int getDni() {
        return this.dni;
    }
    
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    public String getDireccion() {
        return this.direccion;
    }
    
     public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }
    public Date getFechaNacimiento() {
        return this.fechaNacimiento;
    }
    
    public void setSexo(int sexo) {
        this.sexo = sexo;
    }
    public int getSexo() {
        return this.sexo;
    }
}


