import java.util.Date;
import java.util.Calendar;

public class Empleado extends Persona
{
    private Cargo cargo;

    private String titulo;
    private Date fechaIngreso;
    
    public Empleado(Cargo cargo)
    {
        this.cargo = cargo;
    }
    
    public void setCargo(Cargo cargo) {
        this.cargo = cargo;
    }
    public Cargo getCargo() {
        return this.cargo;
    }
    
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    
    public String getTitulo() {
        return this.titulo;
    }
    
    public void setFechaIngreso(Date fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }
    public Date getFechaIngreso() {
        return this.fechaIngreso;
    }


    public double calcularSalario() {
        return cargo.calcularSalario(this); 
    }
    
    public int antiguedad() {
        long ingreso = fechaIngreso.getTime();
        long hoy  = Calendar.getInstance().getTime().getTime();
        
        return (int)(hoy - ingreso)/86400000;
    }
}

    
  