public abstract class Cargo
{
    
    public abstract double calcularSalario(Empleado e);

}