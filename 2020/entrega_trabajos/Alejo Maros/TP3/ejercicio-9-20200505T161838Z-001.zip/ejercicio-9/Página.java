
import java.util.Date;

public class Página
{
    private String direccion;
    private Date fechaVisita;
    private String codigo;
    private int tamaño;
    
    public void setDireccion(String direccion){
        this.direccion = direccion;
        
    }
    
    public String getDireccion(){
        return this.direccion;
    }
    
    public void setFechaVisita(Date fechaVisita){
        this.fechaVisita = fechaVisita;
    }
    
    public Date getFechaVisita(){
        return this.fechaVisita;
    }
    
    public void setCodigo(String codigo){
        this.codigo = codigo;
    }
    
    public String getCodigo(){
        return this.codigo;
    }
    
    public void setTamaño(int tamaño){
        this.tamaño = tamaño;
    }
    
    public int getTamaño(){
        return this.tamaño;
    }
}
