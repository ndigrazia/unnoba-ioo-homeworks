
public class Círculo
{
    private Punto centro;
    private double radio;
    
    public void setPunto(Punto unPunto){
        centro=unPunto;
    }
    
    public void setRadio(int unRadio){
        radio=unRadio;
    }
    
    public void ampliarRadio(float unValor){
        radio+=unValor;
    }
    
    public double calcularArea(){
        return Math.PI*Math.pow(radio, 2);
    }

    public void trasladarCentro(Punto unPunto){
        centro.sumarPunto(unPunto);
    }
}
