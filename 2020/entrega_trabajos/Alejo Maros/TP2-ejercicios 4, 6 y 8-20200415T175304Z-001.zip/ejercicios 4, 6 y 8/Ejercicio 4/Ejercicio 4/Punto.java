
public class Punto
{
    private int x,y;
    
    public void sumarValor(int unValor){
        x+=unValor;
        y+=unValor;
    }
    
        public int getX(){
        return x;
    }
    public int getY(){
        return y;
    }
    
    public void sumarPunto(Punto unPunto){
        x+= unPunto.getX();
        y+= unPunto.getY();
    }
    
    public float distanciaDe(Punto unPunto){
        return (this.x - unPunto.getX())^2 + (this.y - unPunto.getY())^2;
    }
    
    public float distanciaAlOrigen(){
        return distanciaDe(new Punto());
    }
}
