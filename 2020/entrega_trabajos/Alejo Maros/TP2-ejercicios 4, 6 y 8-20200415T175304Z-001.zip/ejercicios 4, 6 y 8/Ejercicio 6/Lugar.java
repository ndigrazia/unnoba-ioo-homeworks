public class Lugar
{
    private String nombre;
    
    public Lugar(){
    }
}
