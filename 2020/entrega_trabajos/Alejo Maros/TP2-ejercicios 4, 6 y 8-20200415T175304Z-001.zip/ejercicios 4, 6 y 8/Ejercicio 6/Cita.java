import java.util.Date;

public class Cita
{
  private Date fecha;
  private Persona contacto;
  private Persona destino;
  private int importancia;
  private Lugar unlugar;
  
  public Cita(){
    }
    
  public void setFecha(Date fecha){
      this.fecha=fecha;
    }
    
  public Date getFecha(){
      System.out.println("retornar fecha:"+ fecha);
      return fecha;
   }
    
  public void setContacto(Persona ubicacion){
        this.contacto=ubicacion;
   }
    
  public Persona getContacto(){
      return contacto;
   }
  public void setPersonaDestino(Persona ubicacion){
      this.destino= ubicacion;
    }
  
  public Persona getDestino(){
      return contacto;
    }
    
  public void setImportancia(int importancia){
      this.importancia=importancia;
    }
    
  public int getImportancia(){
      return importancia;
    }
    
  public void setLugar(Lugar fecha){
       this.unlugar=unlugar;
    }
  public Lugar getLugar(){
      return unlugar;
    }
}
  