public class Persona
{
    private String nombre;
    private String apellido;
    
    public Persona(){
    }
    
    public void setNombre(String nombre){
        this.nombre=nombre;
    }
    
    public String getNombre(){
        return nombre;
    }
}