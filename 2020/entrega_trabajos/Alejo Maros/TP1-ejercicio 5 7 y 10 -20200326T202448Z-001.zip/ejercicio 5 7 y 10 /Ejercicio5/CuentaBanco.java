
/**
 * Write a description of class CuentaBancaria here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

import java.util.Date;
public class CuentaBanco
{
    private int Saldo;
    private Date FechadeCreacion;
    private int Maximo;
    private int Monto;
    private Titular titularCuenta;
    
    public Titular getTitularcuenta(){
        return this.titularCuenta;
    }
    
    public void setTitularcuenta(Titular titularCuenta){
        this.titularCuenta = titularCuenta;
    }
    
    public void Depositar(int Monto){
        Saldo = Saldo + Monto;
    }
    
    public void Extraer(int Monto){
        Saldo = Saldo - Monto;
    }
    
    public int Saldo(){
        return Saldo;
    }

    public void fechacreacion(Date fechaCreacion){
        FechadeCreacion = fechaCreacion;
    }
    
    public int Maximo(){
        return Maximo;
    } 
}
