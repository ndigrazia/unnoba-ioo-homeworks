
/**
 * Write a description of class mp3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class mp3
{
   
    private boolean reproducir= false;
    private int volumen;
    private int volumenmaximo;
    
    
    
      public void REproducir(){
          
          reproducir= true;
          
      }
      public void pausar(){
          
          reproducir= false;
          
        }  
      
      public void subirvolumen(){
        
        if(volumen < volumenmaximo)
           volumen++;
        
        }  
        
      public void bajarvolumen(){
          
          if(volumen > 0)
          
             volumen--;
          
        }
      
      public int getvolumenmax(){
          
          return volumenmaximo;
          
        } 
        
      public void setvolumenmax(int vol){
          
          volumenmaximo= vol;
          
        }
      
     public int volumenactual(){
         
         return volumen;
         
      
          
        
        }
    }
    
