public class reproductorMP3
{
    private String canciones;
    private int volumen = 5;
    private boolean estado = false;
    
    public void reproducir()
    {
        estado = true;
    }
    
    public void pausar()
    {
        estado = false;
    }
    
    public void subirVolumen()
    {
        if(volumen < 10)
        {
            volumen +=1;
        }
        else
        {
            System.out.println("Volumen al maximo");
        }
    }
    
    public void bajarVolumen()
    {
        if(volumen > 1)
        {
            volumen -=1;
        }
        else
        {
            System.out.println("Volumen minimo");
        }
    }
    
    //getters y setters
    
    public void setCancion(String tema)
    {
        canciones = tema;
    }
    
    
}
