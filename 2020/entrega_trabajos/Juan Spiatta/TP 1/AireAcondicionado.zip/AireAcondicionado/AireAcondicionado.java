public class AireAcondicionado
{
    //Atributos
    
    private boolean estado = false;
    private int temperatura = 15;
    
    public void encender()
    {   
        estado = true;
    }
    
    public void apagar()
    {
        estado = false;
    }
    
    public void subirTemperatura()
    {
        if (temperatura < 30)
            {
                temperatura+=1;
            }
        
        else
            {
                System.out.println("Temperatura maxima alcanzada");
            }
    }
    
    public void bajarTemperatura()
    {
        if (temperatura > 10)
            {
                temperatura-=1;
            }
        
        else
            {
                System.out.println("Temperatura minima alcanzada");
            }
    }
}
