
public class cuentaBancaria
{
  //Atributos
  private String titular;
  private float saldo;
  private int maxExtracciones = 5;
  private String fecha;
  
  public void verSaldo()
  {
      System.out.println(saldo);
  }
  
  public void retirarSaldo()
  {
      //Retira saldo
  }
  
  public void transferencias()
  {
      //transferencia
  }
  
  //getters y setters
  
  public String getTitular()
  {
     return titular; 
  }
  
  public void setTitular(String nom)
  {
      titular = nom;
  }
  
  public float getSaldo()
  {
      return saldo;
  }
  
}
