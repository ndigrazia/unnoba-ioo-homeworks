public class Auto
{
    private String color;
    private String modelo;
    private Puertas puertas = new Puertas();
    private Chasis chasis = new Chasis();
    private Motor motor = new Motor();
    private Ruedas ruedas = new Ruedas();
    
    public void abrirPuertas()
    {
        puertas.abrirPuertas();
        System.out.println("Puertas abiertas");
    }
    
    public void cerrarPuertas()
    {
        puertas.cerrarPuertas();
        System.out.println("Puertas cerradas");
    }
    
    public void encender()
    {
        if (puertas.estado == false)
        {
            motor.encender();
            System.out.println("Motor encendido");
        }
        else
        {
            System.out.println("Cerrar las puertas");
        }
    }
    
    public void acelerar()
    {
        
    }
    
    public void frenar()
    {
        
    }
    
    public void apagar()
    {
        motor.apagar();
        System.out.println("Motor apagado");
    }
    
    //Getters and Setters
    
    public void setRuedasMarcas(String marc)
    {
        ruedas.marca = marc;
    }
    
    public void setColor(String c)
    {
        color = c;
    }
    
    public void setModelo(String mod)
    {
        modelo = mod;
    }
}
