public class Motor
{
    public boolean estado = false;
    
    public void encender()
    {
        estado = true;
    }
    
    public void apagar()
    {
        estado = false;
    }
    
    
}
