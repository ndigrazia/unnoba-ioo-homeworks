public class Puertas
{
    public boolean estado = false;
    
    public void abrirPuertas()
    {
        estado = true;
    }
    
    public void cerrarPuertas()
    {
        estado = false;
    }
    
}
