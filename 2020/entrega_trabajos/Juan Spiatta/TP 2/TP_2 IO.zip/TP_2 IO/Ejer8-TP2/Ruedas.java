public class Ruedas
{
    private int cant = 4;
    public String marca;
    
    public void setMarca(String m)
    {
        marca = m;
    }
    
}
