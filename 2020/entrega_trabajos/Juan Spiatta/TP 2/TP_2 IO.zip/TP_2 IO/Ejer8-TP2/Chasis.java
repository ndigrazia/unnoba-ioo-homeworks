public class Chasis
{
    //Medidas generales
    private float largoChasis = 4.419f;
    private float anchoChasis = 1.440f;
}
