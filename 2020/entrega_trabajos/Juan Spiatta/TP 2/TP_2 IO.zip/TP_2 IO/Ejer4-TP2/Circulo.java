import java.util.ArrayList;

public class Circulo
{
   private String centro;
   private int radio;
   private float area;
   private int x;
   private int y;
   
   public void Ampliar(int valor)
   {
       radio += valor;
   }
   
   public float area()
   {
       float π = 3.14f;
       float resultado = (float)Math.pow(radio, 2);
       resultado = resultado*π;
       area=resultado;
       return area;
   }
   
   public void trasladar(int x1, int y1)
   {
       x+=x1;
       y+=y1;
       centro = ("("+x+","+y+")");
   }   
   
   //Getters and Setters
  
   public void setRadio(int valor)
   {
       radio=valor;
   }
   
   public void setCentro(int x1, int y1)
   {
       x=x1;
       y=y1;
       centro = ("("+x+","+y+")");
   }
   
}
