import java.util.Date;
public class Cita 
{  
       private Persona persona;
       private Lugar lugar;
       private String fecha;
       private String horario;
       
       public void contacto(String nombre, String apellido, int edad, int altura)
       {
           persona = new Persona();
           persona.nombre = nombre;
           persona.apellido = apellido;
           persona.edad = edad;
           persona.altura = altura;
       }
       
       public void Lugar(String nombre, String ciudad)
       {
           lugar = new Lugar();
           lugar.nombre=nombre;
           lugar.ciudad=ciudad;
       }
       
       public void setFecha_Hora(int dd, int mm, int aa, int hs, int min)
       {
           if (dd>=1 && dd<=31 && mm>=1 && mm<=12 && aa>0)
           {
               fecha = (dd+"/"+mm+"/"+aa);
           }
           else
           {
               System.out.println("Datos erroneos");
           }
           if (hs>=0 && hs<24 && min>=0 && min<60)
           {
               horario = (hs+":"+min+"hs");
           }
           
           else
           {
               System.out.println("Datos erroneos");
           }
           
       }
}



