public class Lugar 
{  
   public String nombre;
   public String ciudad;
}
