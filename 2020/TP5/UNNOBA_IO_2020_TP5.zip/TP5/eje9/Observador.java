package eje9;

public interface Observador {

	public void actualizar(Sujeto sujeto);

}
