import java.util.Date;
public abstract class Tests
{
    protected Persona persona;
    protected Date fecha;
    protected int tiempo;
    
    public Tests(String nombre, String apellido, int edad, int dni)
    {
        this.persona = new Persona(nombre, apellido, edad, dni);
        this.fecha = new Date();
    }
}
