public class Actor extends Rol
{
    public Actor()
    {
    }
}
