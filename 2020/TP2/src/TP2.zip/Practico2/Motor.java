public class Motor
{
    private boolean encendido;
    
    public Motor()
    {
    }

    public void encender(){
        encendido = true;
    }
    
    public void apagar(){
       encendido = false;
    }

}
