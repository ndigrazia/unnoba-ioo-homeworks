public class Director extends Rol
{
    public Director()
    {
    }
}
