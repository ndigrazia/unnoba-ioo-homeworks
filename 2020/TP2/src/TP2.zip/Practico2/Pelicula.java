public class Pelicula extends Filme
{
    public Pelicula()
    {
    }
}
