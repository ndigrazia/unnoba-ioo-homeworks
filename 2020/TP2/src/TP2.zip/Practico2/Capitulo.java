public class Capitulo
{
    private String desc;
    
    public Capitulo()
    {
    }

    public void setDesc(String d) {
        desc=d;
    }
    
    public String getDesc() {
        return desc;
    }

}
